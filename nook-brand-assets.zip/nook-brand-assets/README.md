# nook — brand asset package

Working brand name. **Trademark clearance not performed.** Public launch and
domain commitment are blocked pending the Nook / Nooks competitive review.

Read `nook-brand-guidelines.md` before using anything here.
`MANIFEST.md` lists every file with dimensions and checksums.

---

## Pick the right file

**Website header, app nav, email signature, invoice**
`svg/nook-logo-primary.svg` on light, `svg/nook-logo-white.svg` on dark.

**App icon**
`svg/nook-app-icon.svg` is the master. Ship `png/nook-app-icon-1024.png` to the
App Store and Play Store — it is deliberately RGB with **no alpha channel**,
which Apple requires. Use `png/nook-app-icon-rounded-1024.png` anywhere a
pre-rounded icon is needed (web, macOS, press).

**Favicon**
```html
<link rel="icon" href="/nook-favicon-32.png" sizes="32x32">
<link rel="icon" href="/nook-favicon-16.png" sizes="16x16">
<link rel="icon" href="/nook-favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/nook-favicon-180.png">
<link rel="mask-icon" href="/nook-favicon-mono.svg" color="#7657F6">
```
The 16px file is pixel-tuned and intentionally differs from the 32px tile: it is
full-bleed with a larger glyph so the stroke survives at that size.

**PWA manifest**
`nook-favicon-192.png` and `nook-favicon-512.png`.

**Social profiles**
`png/nook-social-avatar.png` — safe under a circular crop.

**Print / single colour**
`svg/nook-logo-black.svg`.

**Marketing campaigns only**
`svg/nook-logo-primary-period.svg` — the violet period. Never in product UI,
never below 32px.

---

## Rules worth repeating

- Minimum wordmark size **16px height**. Under that, use the symbol instead.
- Clear space on all sides = **2× stroke weight**.
- Never rebuild the wordmark by typing "nook" in a font. The letterforms are
  custom closed paths and no font will match them.
- The mark must survive in one solid colour. Colour carries no meaning.

---

## Editing

Every SVG is plain, self-contained markup with a correct `viewBox`, no embedded
rasters, no external references and no font dependencies. They open and edit
directly in Figma, Illustrator, Inkscape or a text editor.

All assets derive from one geometry, documented in section 1 of the guidelines.
If you change the wordmark, the monogram, favicon and app icons must be
regenerated from it — they are the same paths, not copies.
